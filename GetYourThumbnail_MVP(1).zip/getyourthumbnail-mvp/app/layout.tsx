import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "GetYourThumbnail — Create thumbnails that get noticed",
  description: "Create eye-catching video thumbnails from your footage.",
  applicationName: "GetYourThumbnail"
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
