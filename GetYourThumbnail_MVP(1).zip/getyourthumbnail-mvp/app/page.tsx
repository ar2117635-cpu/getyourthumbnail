 "use client";

import { ChangeEvent, useEffect, useRef, useState } from "react";
import { ArrowRight, Check, ChevronDown, Clapperboard, Download, ImagePlus, Languages, LockKeyhole, LogIn, Menu, Play, Sparkles, Upload, WandSparkles, X } from "lucide-react";
import { isSupabaseConfigured, supabase } from "@/lib/supabase";

type Design = { id: number; title: string; subtitle: string; style: string; accent: string; badge: string; };
const designs: Design[] = [
  { id: 1, title: "THE BIG REVEAL", subtitle: "YOU WON'T BELIEVE THIS", style: "electric", accent: "#9d4dff", badge: "NEW" },
  { id: 2, title: "EPIC MOMENT", subtitle: "WATCH UNTIL THE END", style: "cinema", accent: "#00d4ff", badge: "MUST SEE" }
];

export default function Home() {
  const [file, setFile] = useState<File | null>(null);
  const [videoUrl, setVideoUrl] = useState("");
  const [frame, setFrame] = useState("");
  const [title, setTitle] = useState("THE BIG REVEAL");
  const [subtitle, setSubtitle] = useState("YOU WON'T BELIEVE THIS");
  const [active, setActive] = useState(0);
  const [generated, setGenerated] = useState(false);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [count, setCount] = useState(0);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [authOpen, setAuthOpen] = useState(false);
  const [loggedIn, setLoggedIn] = useState(false);
  const [mobileMenu, setMobileMenu] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRefs = [useRef<HTMLCanvasElement>(null), useRef<HTMLCanvasElement>(null)];

  useEffect(() => {
    const today = new Date().toISOString().slice(0, 10);
    const saved = localStorage.getItem("gyt-usage");
    if (saved) {
      try { const parsed = JSON.parse(saved); setCount(parsed.date === today ? parsed.count : 0); }
      catch { setCount(0); }
    }
    const savedEmail = localStorage.getItem("gyt-email");
    if (savedEmail) { setEmail(savedEmail); setLoggedIn(true); }
    if (supabase) {
      supabase.auth.getSession().then(({ data }) => {
        if (data.session?.user.email) { setEmail(data.session.user.email); setLoggedIn(true); }
      });
      const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
        if (session?.user.email) { setEmail(session.user.email); setLoggedIn(true); }
        else { setLoggedIn(false); }
      });
      return () => listener.subscription.unsubscribe();
    }
  }, []);

  function handleFile(e: ChangeEvent<HTMLInputElement>) {
    const selected = e.target.files?.[0];
    if (!selected) return;
    if (!selected.type.startsWith("video/")) { setMessage("Please choose a video file."); return; }
    if (selected.size > 500 * 1024 * 1024) { setMessage("This MVP supports video files up to 500 MB. Very large files may depend on your device memory."); return; }
    if (videoUrl) URL.revokeObjectURL(videoUrl);
    const url = URL.createObjectURL(selected);
    setFile(selected); setVideoUrl(url); setFrame(""); setGenerated(false); setMessage("Video loaded. Choose a moment or generate from the first second.");
  }

  function captureFrame() {
    const video = videoRef.current;
    if (!video || !video.videoWidth) { setMessage("Wait for the video preview to load, then try again."); return; }
    const c = document.createElement("canvas");
    c.width = 1280; c.height = 720;
    const ctx = c.getContext("2d");
    if (!ctx) return;
    const scale = Math.max(c.width / video.videoWidth, c.height / video.videoHeight);
    const w = video.videoWidth * scale, h = video.videoHeight * scale;
    ctx.drawImage(video, (c.width - w) / 2, (c.height - h) / 2, w, h);
    setFrame(c.toDataURL("image/jpeg", 0.92));
    setMessage("Frame captured. Generate your two thumbnail concepts.");
  }

  function drawDesign(canvas: HTMLCanvasElement, variant: number, image: string) {
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const img = new Image();
    img.onload = () => {
      canvas.width = 1280; canvas.height = 720;
      const scale = Math.max(1280 / img.width, 720 / img.height);
      const w = img.width * scale, h = img.height * scale;
      ctx.drawImage(img, (1280 - w) / 2, (720 - h) / 2, w, h);
      const grad = ctx.createLinearGradient(0, 0, 1280, 720);
      if (variant === 0) {
        grad.addColorStop(0, "rgba(14,5,35,.18)"); grad.addColorStop(.55, "rgba(13,5,34,.45)"); grad.addColorStop(1, "rgba(8,3,20,.92)");
      } else {
        grad.addColorStop(0, "rgba(0,10,28,.75)"); grad.addColorStop(.48, "rgba(0,15,30,.15)"); grad.addColorStop(1, "rgba(0,0,0,.78)");
      }
      ctx.fillStyle = grad; ctx.fillRect(0, 0, 1280, 720);
      ctx.fillStyle = variant === 0 ? "#a855f7" : "#00d4ff";
      if (variant === 0) { ctx.fillRect(72, 82, 12, 535); }
      else { ctx.fillRect(72, 82, 300, 12); ctx.fillRect(72, 82, 12, 535); }
      ctx.font = "900 34px Arial"; ctx.fillStyle = variant === 0 ? "#e9d5ff" : "#a5f3fc";
      ctx.fillText(variant === 0 ? "✦ EXCLUSIVE" : "▶ FEATURED", 112, 125);
      ctx.font = "900 88px Arial"; ctx.lineWidth = 8; ctx.strokeStyle = "rgba(0,0,0,.7)";
      const main = (variant === 0 ? title : (title || "EPIC MOMENT")).toUpperCase().slice(0, 22);
      ctx.strokeText(main, 112, 470, 1050); ctx.fillStyle = "#ffffff"; ctx.fillText(main, 112, 470, 1050);
      ctx.font = "700 38px Arial"; ctx.fillStyle = variant === 0 ? "#f0abfc" : "#67e8f9";
      ctx.fillText((variant === 0 ? subtitle : "WATCH UNTIL THE END").toUpperCase().slice(0, 38), 116, 535, 1040);
      ctx.fillStyle = variant === 0 ? "#a855f7" : "#0891b2";
      ctx.beginPath(); ctx.roundRect(930, 82, 260, 64, 16); ctx.fill();
      ctx.font = "900 28px Arial"; ctx.fillStyle = "#fff"; ctx.textAlign = "center";
      ctx.fillText(variant === 0 ? "TRENDING NOW" : "DON'T MISS", 1060, 124); ctx.textAlign = "left";
      ctx.fillStyle = "rgba(255,255,255,.78)"; ctx.font = "600 20px Arial"; ctx.fillText("GETYOURTHUMBNAIL", 112, 660);
    };
    img.src = image;
  }

  function generate() {
    if (!file) { setMessage("Upload a video first."); return; }
    if (count >= 2) { setMessage("You have used the 2 daily demo generations on this device. Try again tomorrow."); return; }
    setBusy(true); setMessage("Creating two thumbnail concepts…");
    const video = videoRef.current;
    if (!video) { setBusy(false); return; }
    const doGenerate = () => {
      const c = document.createElement("canvas"); c.width = 1280; c.height = 720;
      const ctx = c.getContext("2d");
      if (!ctx) { setBusy(false); return; }
      const scale = Math.max(1280 / video.videoWidth, 720 / video.videoHeight);
      const w = video.videoWidth * scale, h = video.videoHeight * scale;
      ctx.drawImage(video, (1280-w)/2, (720-h)/2, w, h);
      const data = c.toDataURL("image/jpeg", .92);
      setFrame(data);
      setTimeout(() => {
        canvasRefs.forEach((ref, i) => { if (ref.current) drawDesign(ref.current, i, data); });
        const today = new Date().toISOString().slice(0,10);
        const next = count + 1; setCount(next);
        localStorage.setItem("gyt-usage", JSON.stringify({ date: today, count: next }));
        setGenerated(true); setBusy(false); setActive(0);
        setMessage("Done — two editable thumbnail concepts are ready. This MVP uses your video frame and design templates, not generative AI.");
      }, 100);
    };
    if (video.readyState >= 2) doGenerate();
    else { video.currentTime = 0.5; video.onseeked = doGenerate; }
  }

  function download(index: number) {
    const canvas = canvasRefs[index].current;
    if (!canvas) return;
    const a = document.createElement("a"); a.download = `getyourthumbnail-${index+1}.png`; a.href = canvas.toDataURL("image/png"); a.click();
  }

  async function authenticate(mode: "login" | "signup") {
    if (!email || !password) { setMessage("Enter your email and password."); return; }
    if (supabase) {
      const result = mode === "signup"
        ? await supabase.auth.signUp({ email, password })
        : await supabase.auth.signInWithPassword({ email, password });
      if (result.error) setMessage(result.error.message);
      else { setLoggedIn(true); setAuthOpen(false); setMessage(mode === "signup" ? "Account created. Check your email if confirmation is enabled." : "You are signed in."); }
    } else {
      localStorage.setItem("gyt-email", email); setLoggedIn(true); setAuthOpen(false);
      setMessage("Local demo profile created on this device. Connect Supabase for real accounts and cloud sync.");
    }
  }

  async function signOut() {
    if (supabase) await supabase.auth.signOut();
    localStorage.removeItem("gyt-email"); setLoggedIn(false); setMessage("Signed out.");
  }

  return (
    <main>
      <nav className="nav wrap">
        <a className="brand" href="#"><span className="brand-icon"><WandSparkles size={21}/></span><span>GetYour<span className="gradient-text">Thumbnail</span></span></a>
        <div className={`nav-links ${mobileMenu ? "open" : ""}`}>
          <a href="#studio">AI Studio</a><a href="#how">How it works</a><a href="#pricing">Pricing</a>
        </div>
        <div className="nav-actions">
          {loggedIn ? <button className="btn btn-ghost small" onClick={signOut}>{email.split("@")[0]} · Sign out</button> :
            <button className="btn btn-ghost small" onClick={() => setAuthOpen(true)}><LogIn size={16}/> Log in</button>}
          <a className="btn btn-primary small nav-cta" href="#studio">Start creating <ArrowRight size={16}/></a>
          <button className="mobile-toggle" onClick={() => setMobileMenu(!mobileMenu)} aria-label="Toggle menu">{mobileMenu ? <X/> : <Menu/>}</button>
        </div>
      </nav>

      <section className="hero wrap">
        <div className="hero-copy">
          <div className="eyebrow"><span className="pulse"/> THUMBNAILS BUILT TO GET NOTICED</div>
          <h1>Turn your video into a <span className="gradient-text">scroll-stopping</span> thumbnail.</h1>
          <p className="hero-sub">Upload your footage. Capture the moment. Create bold thumbnail concepts in seconds — no design experience needed.</p>
          <div className="hero-buttons"><a href="#studio" className="btn btn-primary">Create my thumbnail <ArrowRight size={18}/></a><a href="#how" className="btn btn-ghost"><Play size={16}/> See how it works</a></div>
          <div className="trust-row"><span><Check size={15}/> No design skills needed</span><span><Check size={15}/> PNG export</span><span><Check size={15}/> Free to try</span></div>
        </div>
        <div className="hero-art">
          <div className="glow glow-one"/><div className="glow glow-two"/>
          <div className="mock-window">
            <div className="mock-top"><div className="dots"><i/><i/><i/></div><span>YOUR NEXT BIG THUMBNAIL</span><span className="live-tag">● LIVE PREVIEW</span></div>
            <div className="mock-image"><div className="mock-sun"/><div className="mock-mountain m1"/><div className="mock-mountain m2"/><div className="mock-copy"><small>✦ THE MOMENT</small><strong>WORTH<br/>CLICKING.</strong><em>MAKE IT UNMISSABLE</em></div></div>
            <div className="mock-bottom"><span><Sparkles size={14}/> Studio preview</span><span className="mock-pill">1280 × 720</span></div>
          </div>
          <div className="float-card"><span className="float-icon"><Check size={17}/></span><div><b>Ready to stand out</b><small>Made for your next upload</small></div></div>
        </div>
      </section>

      <section className="stats wrap"><div><b>1280 × 720</b><span>HD thumbnail canvas</span></div><div><b>2 concepts</b><span>Every daily free try</span></div><div><b>PNG</b><span>Ready to download</span></div><div><b>21 languages</b><span>Planned product support</span></div></section>

      <section className="studio-section" id="studio">
        <div className="wrap">
          <div className="section-heading"><div className="eyebrow">✦ YOUR CREATIVE WORKSPACE</div><h2>Make your next <span className="gradient-text">thumbnail.</span></h2><p>Start with a video, then customize the words and export your design.</p></div>
          <div className="studio-grid">
            <div className="panel upload-panel">
              <div className="panel-title"><span className="step">01</span><div><h3>Upload your video</h3><p>MP4, MOV, WebM and other browser-supported formats</p></div></div>
              <label className="dropzone">
                <input type="file" accept="video/*" onChange={handleFile}/>
                <span className="upload-icon"><Upload size={24}/></span><b>{file ? file.name : "Drop your video here"}</b><span>{file ? `${(file.size/1024/1024).toFixed(1)} MB · Loaded` : "or tap to browse your device"}</span><small>Maximum file size: 500 MB (device/browser dependent)</small>
              </label>
              {videoUrl && <div className="video-box"><video ref={videoRef} src={videoUrl} controls playsInline onLoadedMetadata={() => setMessage("Video ready. Generate thumbnails when you are ready.")}/><button className="btn btn-ghost small" onClick={captureFrame}><ImagePlus size={15}/> Capture current frame</button></div>}
              <div className="usage"><span>Daily free generations</span><b>{Math.max(0,2-count)} / 2 left</b></div><div className="usage-track"><i style={{width:`${Math.min(100,count*50)}%`}}/></div>
              <button className="btn btn-primary full generate-btn" onClick={generate} disabled={!file || busy}><WandSparkles size={18}/>{busy ? "Creating concepts…" : "Generate 2 thumbnails"}<ArrowRight size={17}/></button>
              <p className="fine-print"><LockKeyhole size={12}/> Demo usage limit is stored on this device. Server-enforced limits require backend setup.</p>
            </div>
            <div className="panel result-panel">
              <div className="panel-title"><span className="step">02</span><div><h3>Your thumbnail concepts</h3><p>Choose a design and customize its headline</p></div></div>
              {generated ? <div className="results">
                <div className="design-tabs"><button className={active===0?"selected":""} onClick={()=>setActive(0)}>Concept 01</button><button className={active===1?"selected":""} onClick={()=>setActive(1)}>Concept 02</button></div>
                <div className="canvas-wrap"><canvas ref={canvasRefs[0]} className={active===0?"show":"hide"}/><canvas ref={canvasRefs[1]} className={active===1?"show":"hide"}/></div>
                <div className="edit-controls"><label>Headline<input value={title} maxLength={22} onChange={e=>setTitle(e.target.value)} onBlur={()=>frame && canvasRefs.forEach((r,i)=>r.current&&drawDesign(r.current,i,frame))}/></label><label>Subheading<input value={subtitle} maxLength={38} onChange={e=>setSubtitle(e.target.value)} onBlur={()=>frame && canvasRefs.forEach((r,i)=>r.current&&drawDesign(r.current,i,frame))}/></label><button className="btn btn-primary full" onClick={()=>download(active)}><Download size={17}/> Download PNG</button></div>
              </div> : <div className="empty-result"><div className="empty-icon"><Clapperboard size={30}/></div><b>Your designs will appear here</b><span>Upload a video and generate two thumbnail concepts to get started.</span><div className="empty-preview"><div/><div/><div/></div></div>}
            </div>
          </div>
          {message && <div className="notice" role="status"><span>{message}</span><button onClick={()=>setMessage("")} aria-label="Dismiss"><X size={15}/></button></div>}
        </div>
      </section>

      <section className="how-section wrap" id="how">
        <div className="section-heading"><div className="eyebrow">SIMPLE BY DESIGN</div><h2>From footage to <span className="gradient-text">thumbnail.</span></h2><p>A quick workflow to help your content make a stronger first impression.</p></div>
        <div className="steps"><article><span>01</span><Upload/><h3>Upload a video</h3><p>Choose a clip from your device and preview it in the studio.</p></article><article><span>02</span><WandSparkles/><h3>Create concepts</h3><p>Generate two visual layouts using a frame from your footage.</p></article><article><span>03</span><Download/><h3>Customize & export</h3><p>Edit the headline and save a 1280 × 720 PNG file.</p></article></div>
      </section>

      <section className="pricing-section" id="pricing"><div className="wrap pricing-inner"><div><div className="eyebrow">START CREATING TODAY</div><h2>Simple tools. <span className="gradient-text">Big first impressions.</span></h2><p>The initial MVP is free to test. Advanced plans and billing will be added in a later release.</p></div><div className="price-card"><span className="price-label">MVP FREE ACCESS</span><div className="price">$0 <small>/ for now</small></div><ul><li><Check/> 2 demo generations per day</li><li><Check/> Two thumbnail concepts</li><li><Check/> Basic headline editing</li><li><Check/> PNG download</li></ul><a href="#studio" className="btn btn-primary full">Try the studio <ArrowRight size={16}/></a></div></div></section>

      <footer className="footer wrap"><a className="brand" href="#"><span className="brand-icon"><WandSparkles size={19}/></span><span>GetYour<span className="gradient-text">Thumbnail</span></span></a><span>© {new Date().getFullYear()} GetYourThumbnail. Built for creators.</span><span className="footer-links"><a href="/privacy">Privacy</a><a href="/terms">Terms</a></span></footer>

      {authOpen && <div className="modal-backdrop" onClick={()=>setAuthOpen(false)}><div className="auth-modal" onClick={e=>e.stopPropagation()}><button className="modal-close" onClick={()=>setAuthOpen(false)}><X/></button><span className="brand-icon"><WandSparkles/></span><h2>Welcome to the studio</h2><p>{isSupabaseConfigured ? "Sign in or create your account." : "Demo profile — connect Supabase to enable real accounts."}</p><label>Email<input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com"/></label><label>Password<input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="At least 6 characters"/></label><button className="btn btn-primary full" onClick={()=>authenticate("login")}>Log in</button><button className="btn btn-ghost full" onClick={()=>authenticate("signup")}>Create account</button></div></div>}
    </main>
  );
}
